package com.cg.github.stepdefinitions;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.github.pagebeans.LoginPage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class GitHubStepDefinition {
	
	private WebDriver driver;
	private LoginPage loginPage;
	
	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\Softwares\\ChromeDriver\\chromedriver.exe");
	}
	
	@Given("^user is on GitHub login Page$")
	public void user_is_on_GitHub_login_Page() throws Throwable {
	    driver = new ChromeDriver();
	    driver.get("https://github.com/login");
	    loginPage = PageFactory.initElements(driver, LoginPage.class);
	}

	@When("^User enters Invalid username and password$")
	public void user_enters_Invalid_username_and_password() throws Throwable {
		loginPage.setUsername("DaipayanGuha");
	    loginPage.setPassword("12345");
	    loginPage.clickSignIn();
	}

	@Then("^'Incorrect username or password' is displayed on the screen$")
	public void incorrect_username_or_password_is_displayed_on_the_screen() throws Throwable {
	    String expectedErrorMessage = "Incorrect username or password";
	    Assert.assertEquals(expectedErrorMessage, loginPage.getActualErrorMessage());
	}

	@When("^User enters Valid username and password$")
	public void user_enters_Valid_username_and_password() throws Throwable {
		loginPage.setUsername("DaipayanGuha");
	    loginPage.setPassword("daipayan123!");
	    loginPage.toString();
	}

	@Then("^'Correct username and password' is displayed on the screen$")
	public void correct_username_and_password_is_displayed_on_the_screen() throws Throwable {
	    String actualTitle = driver.getTitle();
	    String expectedTitle = "DaipayanGuha";
	    Assert.assertEquals(expectedTitle,actualTitle);
	}
	
	@After
	public void tearDownStepEnv() {
		driver.close();
	}

	
}
